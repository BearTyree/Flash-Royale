import Header from "@/components/Header.js";

export default function NotFound() {
  return (
    <>
      <Header />
      Page Not Found
    </>
  );
}
